#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseStamped
from cv_bridge import CvBridge
import cv2
import numpy as np
from ultralytics import YOLO
import message_filters


class PersonFollower(Node):
    def __init__(self):
        super().__init__('person_follower')
        
        # Declarar parámetros
        self.declare_parameter('model_path', '/home/uli/hszg/ros2_ws/src/tracker/models/best.pt')
        self.declare_parameter('confidence_threshold', 0.5)
        self.declare_parameter('rgb_topic', '/camera/color/image_raw')
        self.declare_parameter('depth_topic', '/camera/depth/image_raw')
        self.declare_parameter('camera_info_topic', '/camera/color/camera_info')
        self.declare_parameter('pose_topic', '/person_pose')
        self.declare_parameter('debug_image_topic', '/person_tracker/debug_image')
        self.declare_parameter('publish_debug_image', True)
        
        # Obtener parámetros
        model_path = self.get_parameter('model_path').value
        self.confidence_threshold = self.get_parameter('confidence_threshold').value
        rgb_topic = self.get_parameter('rgb_topic').value
        depth_topic = self.get_parameter('depth_topic').value
        camera_info_topic = self.get_parameter('camera_info_topic').value
        pose_topic = self.get_parameter('pose_topic').value
        debug_image_topic = self.get_parameter('debug_image_topic').value
        self.publish_debug = self.get_parameter('publish_debug_image').value
        
        # Bridge de OpenCV
        self.bridge = CvBridge()
        
        # Cargar modelo YOLO
        self.get_logger().info(f'Cargando modelo YOLO desde: {model_path}')
        self.model = YOLO(model_path)
        self.get_logger().info('Modelo YOLO cargado exitosamente')
        
        # Parámetros intrínsecos de la cámara (se actualizarán con CameraInfo)
        self.fx = None
        self.fy = None
        self.cx = None
        self.cy = None
        self.camera_info_received = False
        
        # Suscriptor de CameraInfo
        self.camera_info_sub = self.create_subscription(
            CameraInfo,
            camera_info_topic,
            self.camera_info_callback,
            10
        )
        
        # Sincronización de mensajes RGB y Depth
        self.rgb_sub = message_filters.Subscriber(self, Image, rgb_topic)
        self.depth_sub = message_filters.Subscriber(self, Image, depth_topic)
        
        # Sincronizador aproximado
        self.ts = message_filters.ApproximateTimeSynchronizer(
            [self.rgb_sub, self.depth_sub],
            queue_size=10,
            slop=0.1  # 100ms de tolerancia
        )
        self.ts.registerCallback(self.synchronized_callback)
        
        # Publisher de pose
        self.pose_pub = self.create_publisher(PoseStamped, pose_topic, 10)
        
        # Publisher de imagen de debug (opcional)
        if self.publish_debug:
            self.debug_image_pub = self.create_publisher(Image, debug_image_topic, 10)
        
        # Variable para almacenar la última persona detectada
        self.last_person_bbox = None
        
        self.get_logger().info('Nodo PersonFollower iniciado correctamente')
    
    def camera_info_callback(self, msg):
        """Callback para obtener los parámetros intrínsecos de la cámara"""
        if not self.camera_info_received:
            self.fx = msg.k[0]  # K[0,0]
            self.fy = msg.k[4]  # K[1,1]
            self.cx = msg.k[2]  # K[0,2]
            self.cy = msg.k[5]  # K[1,2]
            self.camera_info_received = True
            self.get_logger().info(
                f'Parámetros de cámara recibidos: fx={self.fx:.2f}, fy={self.fy:.2f}, '
                f'cx={self.cx:.2f}, cy={self.cy:.2f}'
            )
    
    def synchronized_callback(self, rgb_msg, depth_msg):
        """Callback sincronizado para procesar RGB y Depth"""
        try:
            # Convertir mensajes ROS a imágenes OpenCV
            rgb_image = self.bridge.imgmsg_to_cv2(rgb_msg, desired_encoding='bgr8')
            depth_image = self.bridge.imgmsg_to_cv2(depth_msg, desired_encoding='passthrough')
            
            # Detectar personas con YOLO
            results = self.model(rgb_image, conf=self.confidence_threshold, verbose=False)
            
            # Procesar detecciones
            person_detected = False
            best_person = None
            max_confidence = 0.0
            
            for result in results:
                boxes = result.boxes
                for box in boxes:
                    # Verificar si es una persona (clase 0 en COCO)
                    # Ajusta esto si tu modelo tiene diferentes clases
                    cls = int(box.cls[0])
                    conf = float(box.conf[0])
                    
                    # Obtener coordenadas del bounding box
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                    
                    # Seleccionar la persona con mayor confianza
                    if conf > max_confidence:
                        max_confidence = conf
                        best_person = {
                            'bbox': (int(x1), int(y1), int(x2), int(y2)),
                            'confidence': conf,
                            'class': cls
                        }
                        person_detected = True
            
            if person_detected and self.camera_info_received:
                bbox = best_person['bbox']
                x1, y1, x2, y2 = bbox
                
                # Calcular el centro del bounding box
                center_x = int((x1 + x2) / 2)
                center_y = int((y1 + y2) / 2)
                
                # Obtener la profundidad en el centro de la persona
                # Usamos una región pequeña alrededor del centro para más estabilidad
                depth_region = depth_image[
                    max(0, center_y-10):min(depth_image.shape[0], center_y+10),
                    max(0, center_x-10):min(depth_image.shape[1], center_x+10)
                ]
                
                # Filtrar valores inválidos (0 o NaN)
                valid_depths = depth_region[depth_region > 0]
                
                if len(valid_depths) > 0:
                    # Usar la mediana para mayor robustez
                    depth = np.median(valid_depths)
                    
                    # Convertir profundidad a metros si está en milímetros
                    # Ajusta esto según tu sensor
                    if depth > 100:  # Probablemente está en milímetros
                        depth = depth / 1000.0
                    
                    # Calcular posición 3D en el frame de la cámara
                    X = (center_x - self.cx) * depth / self.fx
                    Y = (center_y - self.cy) * depth / self.fy
                    Z = depth
                    
                    # Crear y publicar mensaje PoseStamped
                    pose_msg = PoseStamped()
                    pose_msg.header.stamp = rgb_msg.header.stamp
                    pose_msg.header.frame_id = rgb_msg.header.frame_id  # Normalmente "camera_color_optical_frame"
                    
                    pose_msg.pose.position.x = float(X)
                    pose_msg.pose.position.y = float(Y)
                    pose_msg.pose.position.z = float(Z)
                    
                    # Orientación por defecto (apuntando hacia adelante)
                    pose_msg.pose.orientation.w = 1.0
                    pose_msg.pose.orientation.x = 0.0
                    pose_msg.pose.orientation.y = 0.0
                    pose_msg.pose.orientation.z = 0.0
                    
                    self.pose_pub.publish(pose_msg)
                    
                    self.get_logger().info(
                        f'Persona detectada en: X={X:.2f}m, Y={Y:.2f}m, Z={Z:.2f}m '
                        f'(conf={best_person["confidence"]:.2f})'
                    )
                    
                    # Actualizar última detección
                    self.last_person_bbox = bbox
                    
                    # Publicar imagen de debug si está habilitado
                    if self.publish_debug:
                        self.publish_debug_image(rgb_image, bbox, X, Y, Z, best_person['confidence'])
                else:
                    self.get_logger().warn('No se pudo obtener profundidad válida')
            
            elif not self.camera_info_received:
                self.get_logger().warn('Esperando información de la cámara...')
            else:
                self.get_logger().debug('No se detectó ninguna persona')
                
        except Exception as e:
            self.get_logger().error(f'Error en el callback: {str(e)}')
    
    def publish_debug_image(self, image, bbox, X, Y, Z, confidence):
        """Publicar imagen con visualización de la detección"""
        debug_img = image.copy()
        x1, y1, x2, y2 = bbox
        
        # Dibujar bounding box
        cv2.rectangle(debug_img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        
        # Dibujar punto central
        center_x = int((x1 + x2) / 2)
        center_y = int((y1 + y2) / 2)
        cv2.circle(debug_img, (center_x, center_y), 5, (0, 0, 255), -1)
        
        # Añadir texto con información
        text = f'Person: {confidence:.2f}'
        cv2.putText(debug_img, text, (x1, y1-10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        
        pos_text = f'X:{X:.2f} Y:{Y:.2f} Z:{Z:.2f}m'
        cv2.putText(debug_img, pos_text, (x1, y2+20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
        
        # Convertir y publicar
        try:
            debug_msg = self.bridge.cv2_to_imgmsg(debug_img, encoding='bgr8')
            self.debug_image_pub.publish(debug_msg)
        except Exception as e:
            self.get_logger().error(f'Error al publicar imagen de debug: {str(e)}')


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = PersonFollower()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f'Error: {str(e)}')
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()