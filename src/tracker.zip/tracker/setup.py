from setuptools import setup
import os
from glob import glob

package_name = 'tracker'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # Incluir los modelos
        (os.path.join('share', package_name, 'models'), glob('models/*.pt')),
        (os.path.join('share', package_name, 'models'), glob('models/*.jpg')),
        # Incluir archivos de configuración si los tienes
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        # Incluir launch files si los creas
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='uli',
    maintainer_email='your_email@example.com',
    description='Person tracker using YOLO and depth camera',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'follower = tracker.follower:main',
        ],
    },
)